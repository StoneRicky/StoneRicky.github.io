---
title: StrongSwan 5.6.3 安装手札
url: 689.html
id: 689
categories:
  - 咸鱼翻身
date: 2019-02-28 17:08:49
tags:
---

本片为上篇的总结，仅有执行方式。

下载Quericy前辈的脚本：

    wget --no-check-certificate https://raw.githubusercontent.com/quericy/one-key-ikev2-vpn/master/one-key-ikev2.sh

修改脚本文件：

    vim one-key-ikev2.sh

在35%左右的位置找到5.5.1，替换成5.6.3，修改完成后保存。

授权：

    chmod +x one-key-ikev2.sh

运行：

    bash one-key-ikev2.sh